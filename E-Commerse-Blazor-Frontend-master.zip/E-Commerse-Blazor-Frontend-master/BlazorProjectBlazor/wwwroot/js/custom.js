﻿function CloseLoginModal() {
    $(".close").click();
    $("#loginText").val('');  
    $("#passwordText").val('');   
}