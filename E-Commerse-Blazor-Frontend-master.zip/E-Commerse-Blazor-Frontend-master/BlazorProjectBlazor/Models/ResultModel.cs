﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Northwİnd.Blazor.Models
{
    public class ResultModel
    {
        public object Result { get; set; }
        public object Error { get; set; }
    }
}
