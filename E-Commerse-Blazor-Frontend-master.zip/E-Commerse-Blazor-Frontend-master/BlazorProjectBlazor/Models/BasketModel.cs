﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Northwİnd.Blazor.Models
{
    public class BasketModel
    {        
        public int Quantity { get; set; }
        public ProductModel Product { get; set; }        
    }
}
